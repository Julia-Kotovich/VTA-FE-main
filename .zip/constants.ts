// export const API_BASE_URL: string = "http://16.16.186.167:8000/api/";
export const API_BASE_URL: string = "http://vta-api.kpodjiemmanuel.com/api/";
// export const API_BASE_URL: string = "http://127.0.0.1:8000/api/";
// export const API_BASE_URL: string = "http://127.0.0.1:8000/api/";
