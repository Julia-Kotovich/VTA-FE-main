import { useContext, useState,useEffect } from "react";
import { createContext } from "react";
import { API_BASE_URL } from "@/constants";
import axios from "axios";
import { uuidv7 } from "uuidv7";



interface ChatMessage {
  userText: string;
  VTAText: string;
  like: boolean,
  dislike:boolean
}

interface VTAContextType {
  isOpenModal: boolean;
  handleModal: () => void;
  chatHistory: ChatMessage[];
  addChatMessage: (userQuery: string, VTAResponse: string) => void;
  generateVTAResponse: (query: string) => Promise<string>;
  currentUserId: string;
  updateLikeStatus: (like: boolean, dislike: boolean, id: number) =>void;
}
const ChatContext = createContext<VTAContextType | null>( null);
export const ChatProvider = ({children,}: Readonly<{children: React.ReactNode;}>) => {
  const [isOpenModal, setIsOpenModal] = useState<boolean>(false);
  const [likeUpdated, setLikeUpdated] = useState(false);
  // const [chatHistory, setChatHistory] = useState<ChatMessage[]>([]);
  
  const currentUserId = (uuidv7()).toString();

const [chatHistory, setChatHistory] = useState<ChatMessage[]>(() => {
  // Check if code is running in a browser environment
  if (typeof window !== "undefined" && typeof localStorage !== "undefined") {
    const savedHistory = localStorage.getItem("VTAChatHistory");
    return savedHistory ? JSON.parse(savedHistory) : [];
  } else {
    return [];
  }
});

  // Save chat history to localStorage
  // useEffect(() => {
  //    if (typeof window !== "undefined" && typeof localStorage !== "undefined") {
  //      const savedHistory = localStorage.getItem("VTAChatHistory");
  //      setChatHistory(savedHistory ? JSON.parse(savedHistory) : []);
  //    } else {
  //    }
  // }, []);
  
  useEffect(() => {
  
    if (typeof window !== "undefined" && typeof localStorage !== "undefined") {
      localStorage.setItem("VTAChatHistory", JSON.stringify(chatHistory));
    }
  }, [chatHistory,setLikeUpdated]);

  const handleModal = () => {
    return setIsOpenModal(!isOpenModal);
  };

  // Function to generate chatbot response
  const generateVTAResponse = async (query: string): Promise<string> => {
    try {
      const requestData = {
        query: query,
      };
      const response = await axios.post(
        `${API_BASE_URL}vta-answer/`,
        requestData
      );
      const VTAResponse = response.data.response;
      return VTAResponse;
    } catch (error) {
      console.log("Error requesting answer from VTA", error);
      return "Failed to retrieve answer from VTA";
    }
  };

  // Function to add a new chat message to the chat history
  const addChatMessage = (userQuery: string, VTAResponse: string) => {
    const newChatMessage: ChatMessage = {
      userText: userQuery,
      VTAText: VTAResponse,
      like: false,
      dislike: false
    };
    setChatHistory((prevHistory) => [...prevHistory, newChatMessage]);
  };

  const updateLikeStatus = (like: boolean, dislike: boolean, id: number) =>{
    
    if (typeof window !== "undefined" && typeof localStorage !== "undefined") {
      chatHistory[id].like = like;
      chatHistory[id].dislike = dislike;     
      localStorage.setItem("VTAChatHistory", JSON.stringify(chatHistory));
      setLikeUpdated(!likeUpdated);
    } else {
      return []; 
    } 
  }

  return (
    <ChatContext.Provider
      value={{
        isOpenModal,
        handleModal,
        chatHistory,
        addChatMessage,
        generateVTAResponse,
        currentUserId,
        updateLikeStatus
      }}
    >
      {children}
    </ChatContext.Provider>
  );
};

export const useChatContext = ():VTAContextType => {
  const context = useContext(ChatContext);
  if (!context) {
    throw new Error("setup chatContext");
    }
  return context;
}