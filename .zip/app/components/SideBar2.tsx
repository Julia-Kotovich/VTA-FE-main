import React from "react";

export default function SideBar() {
  return (
    <>
      <div
        className="h-[100vh] sm:ml-[0] ml-[-13rem] shadow-md "
        id="sidebar-wrapper"
      >
        <ul className="w-[13rem] main-prm-bg-color ">
          <p>
            side barlre Lorem ipsum dolor sit, amet consectetur ad ipisicing
            elit. Veniam, sunt q uis animi omnis voluptatibus labore officia
            dolorem sequi reprehenderit ad dolore excepturi atque , pariatur
            impedit debitis, repellendus maxime ab possimus?{" "}
          </p>
        </ul>
      </div>
    </>
  );
}
