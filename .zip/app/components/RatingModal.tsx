import Image from 'next/image';
import React, { useState } from 'react'
import { useChatContext } from '../Context/ChatContext';
import { IoStarSharp } from "react-icons/io5";
import { API_BASE_URL } from "@/constants";
import axios from "axios";
import { toast } from 'react-toastify';
import { errorMonitor } from 'events';

export default function RatingModal({ isOpen }: { isOpen: boolean }) {
  const useChat = useChatContext();
  const stars = [1,2,3,4,5]
  const [rating, setRating] = useState(0);
  const [message, setMessage] = useState('');
  const [sending, setSending] = useState(false);


  const handleRating = async (ev: any): Promise<void> => {
    setSending(true)
    ev.preventDefault();
      try {
        const requestData = {
          message: message,
        };
        const response = await axios.post(`${API_BASE_URL}vta/rate/`,requestData);
        const successMessage = response.data.response;
        toast.success(successMessage, {
         position: "top-right",
         autoClose: 5000,
         hideProgressBar: false,
         closeOnClick: true,
         pauseOnHover: true,
         draggable: true,
         progress: undefined,
         theme: "light",
        });
      
        setMessage('');
        setSending(false)
      useChat.handleModal() // close modal
      } catch (error) {
        console.log("Error rating VTA", error);
        const errorMessage = "Failed to send feedback. Please try again later";
        toast.error(errorMessage, {
          position: "top-right",
          autoClose: 5000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          progress: undefined,
          theme: "light",
        });
        setMessage("");
        setSending(false);
        useChat.handleModal(); // close modal
      }
  };
  


  const handleStars = (ev: any) => {
    console.log(ev.target.index)
  }





  return (
    <>
      <div
        className={`sm:w-full md:w-1/2 h-[55vh] main-sec-v2-bg-color absolute top-0 left-0 bottom-0 right-0 m-auto rounded z-10 ${
          !isOpen && "hidden"
        }`}
      >
        <form onSubmit={handleRating}>
          <div className="flex justify-between p-2 flex-nowrap items-center">
            <h5 className="bot-font tracking-widest text-xs md:text-sm">YOUR FEEDBACK</h5>
            <Image
              src="/close.svg"
              alt="close-icon"
              width={35}
              height={35}
              className="bot-font w-10 h-10 hover:bg-[#0b1423] hover:scale-110 hover:cursor-pointer  p-2 rounded-full"
              onClick={() => useChat.handleModal()}
            />
          </div>
          <div className="m-2">
            <textarea
              name="review"
              id="item_description"
              placeholder="Write your review here"
              className="block main-sec-bg-color px-2 rounded-md border-0 py-1.5 text-white shadow-sm 
                  placeholder:text-[#adf7de] focus:ring-0  focus:ring-[#adf7de] sm:text-sm sm:leading-6
                  w-11/12 h-[10rem] m-auto relative"
              onChange={(ev)=>setMessage(ev.target.value)}
            ></textarea>
          </div>
          {/* <div className='ps-3 flex gap-2'>
            {stars.map((star,index)=>(
              <>
                <p>{index}</p>
                <IoStarSharp className={` ${ rating <= star  ? 'text-yellow-400' :  'text-white' } cursor-pointer`} key={index} onClick={handleStars}/>
            </>
            ))
          }
            
         
          </div> */}
          <div className="flex justify-center mt-3">
            <input
              type="submit"
              value="SEND"
              className={`bot-font-2 main-prm-bg-color p-3 font-bold w-1/2 rounded  ${ sending ? 'cursor-not-allowed' : 'hover:bg-yellow-500 cursor-pointer'} `}
              disabled={sending}
            />
          </div>
        </form>
      </div>
    </>
  );
}
