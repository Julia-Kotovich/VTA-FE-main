import Image from 'next/image';
import React from 'react'

export default function UserChat({message}:{message:string}) {
  return (
    <>
      <div className="mb-1">
        <div className="bg-[#586269] p-2 rounded-full h-[2rem] w-[2rem] flex justify-center items-center">
          <Image src="/user.svg" alt="star-icon" width={20} height={20} />
        </div>
        <div className="ms-12">
          <p className="w-[95%] text-white sm:text-sm">
            {message}
          </p>
        </div>
      </div>
    </>
  );
}
