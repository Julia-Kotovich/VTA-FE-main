import React, {  useEffect, useState } from "react";
import BotSVG from "../../public/bot.svg";
import Link from "next/link";
import Image from "next/image";
import { useChatContext } from "../Context/ChatContext";
import { useRouter } from "next/router";

export default function SideBar() {

  const [isOpenModal, setIsOpenModal] = useState(false)
  const useChat = useChatContext();
  
  return (
    <>
      <div
        className="h-[100vh] sm:ml-[0] ml-[-13rem] shadow-md "
        id="sidebar-wrapper"
      >
        <div className="w-[13rem] flex flex-col gap-5 justify-around">
          <div className="w-[4.2rem] flex justify-center items-center main-sec-bg-color m-auto h-[100px] mt-[2rem] rounded-full">
            <Link
              href="/"
              className="hover:bg-[#586269] hover:scale-110  hover:rounded-full p-2 h-[3.2rem] w-[3.2rem]"
              id="homeBtn"
            >
              <Image src="/bot.svg" alt="bot-icon" width={34} height={30} />
            </Link>
          </div>
          <div className="w-[4.2rem] main-sec-bg-color m-auto h-[400px] rounded-full py-2">
            <ul className="p-2 space-y-4">
              <li className="hover:bg-[#586269] hover:scale-110 flex justify-center items-center pt-1 hover:rounded-full h-[3.3rem] w-[3.3rem] text-center">
                <Link href="/chat" className="">
                  <Image
                    src="/chat.svg"
                    alt="chat-icon"
                    width={35}
                    height={35}
                  />
                </Link>
              </li>
              <li className="hover:bg-[#586269] hover:scale-110  flex justify-center items-center pt-1 hover:rounded-full h-[3.3rem] w-[3.3rem] text-center">
                <Link href="#" className="">
                  <Image
                    src="/history.svg"
                    alt="history-icon"
                    width={35}
                    height={35}
                  />
                </Link>
              </li>
              <li className="hover:bg-[#586269] hover:scale-110  flex justify-center items-center pt-1 hover:rounded-full h-[3.3rem] w-[3.3rem] text-center">
                <Link
                  href="#"
                  className=""
                  onClick={() => useChat.handleModal()}
                >
                  <Image
                    src="/star.svg"
                    alt="star-icon"
                    width={35}
                    height={35}
                  />
                </Link>
              </li>
              <li className="hover:bg-[#586269] hover:scale-110  flex justify-center items-center pt-1 hover:rounded-full h-[3.3rem] w-[3.3rem] text-center">
                <Link href="#" className="">
                  <Image
                    src="/settings.svg"
                    alt="settings-icon"
                    width={35}
                    height={35}
                  />
                </Link>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </>
  );
}
