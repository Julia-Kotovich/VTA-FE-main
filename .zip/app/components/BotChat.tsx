import Image from 'next/image';
import React, { useEffect, useState } from 'react'
import { AiFillDislike } from "react-icons/ai";
import { AiFillLike } from "react-icons/ai";
import { API_BASE_URL } from "@/constants";
import axios from "axios";
import { useChatContext } from '../Context/ChatContext';


interface BotChatProps {
  message: string;
  chatId: number;
  currentUserId: string;
  like: boolean;
  dislike: boolean;
}

export default function BotChat({ message, chatId,currentUserId,like,dislike }: BotChatProps): JSX.Element {
  const [isLiked,setIsLiked ]= useState(false)
  const [isDisLiked, setIsDisLiked] = useState(false)
  console.log('currentUser', currentUserId)
  const useChat = useChatContext();
  
  
  async function handleLIke(ev:any) {
    const chatHistory = localStorage.getItem("VTAChatHistory")
    let data = null;
    let parsedChatHistory = null;
    if (chatHistory !== null) {
      try {
         parsedChatHistory = JSON.parse(chatHistory);
        if (Array.isArray(parsedChatHistory)) {
          data = parsedChatHistory[chatId]          
        }
      } catch (error) {
        console.log("failed to parse chat history");
      }
    }
    Object.assign(data, { userId: currentUserId, likeStatus: !isLiked });  
    try {
      const response = await axios.post(`${API_BASE_URL}vta/like/`, data);
      const ratingResponse = response.data.response;
      useChat.updateLikeStatus(!isLiked,false,chatId)
      console.log(ratingResponse);
    } catch (error) {
      console.log("Failed to rate chat", error);
      return "Failed to rate chat";
    }
       
    setIsLiked(!isLiked);  
    setIsDisLiked(false);
  }




  async function handleDisLIke(ev: any) {

    const chatHistory = localStorage.getItem("VTAChatHistory");
    let data = null;
    let parsedChatHistory = null;
       if (chatHistory !== null) {
         try {
            parsedChatHistory = JSON.parse(chatHistory);
           if (Array.isArray(parsedChatHistory)) {
             data = parsedChatHistory[chatId];
           }
         } catch (error) {
           console.log("failed to parse chat history");
         }
       }
       Object.assign(data, {
         userId: currentUserId,
         likeStatus: !isDisLiked,
       });
       try {
         const response = await axios.post(`${API_BASE_URL}vta/dislike/`, data);
         const ratingResponse = response.data.response;
         useChat.updateLikeStatus(false, !isDisLiked, chatId);
         console.log(ratingResponse);
       } catch (error) {
         console.log("Failed to rate chat", error);
         return "Failed to rate chat";
       }
  

      setIsDisLiked(!isDisLiked);
      setIsLiked(false);
  }

  
  return (
    <>
      <div className="ms-5 md:ms-12 mt-5">
        <div className="bg-[#586269] p-2 rounded-full h-[2rem] w-[2rem] flex justify-center items-center">
          <Image src="/bot.svg" alt="star-icon" width={18} height={18} />
        </div>
        <div className="ms-12">
          <p className="w-[95%] text-white sm:text-sm">
            {message}
            <span className="float-right text-white flex gap-1">
              <AiFillLike
                className={`${like ? "text-yellow-400" : ""} cursor-pointer`}
                onClick={handleLIke}
              />
              <AiFillDislike
                className={`${dislike ? "text-yellow-400" : ""} cursor-pointer`}
                onClick={handleDisLIke}
              />
            </span>
          </p>
        </div>
      </div>
    </>
  );
}
