"use client";
import Image from "next/image";
import React, { useEffect, useRef, useState } from "react";
import HomeContent from "./HomeContent";
import UserChat from "./UserChat";
import BotChat from "./BotChat";
import { useChatContext } from "../Context/ChatContext";
import RatingModal from "./RatingModal";
import HeaderSection from "./Header";
import useCsrfToken from "../hooks/usecsrf";

interface ChatType{
  userPrompt: string,
  botResponse: string
};
interface MainContentProps {
  children: React.ReactNode;
  target: string;
}
export const MainContent:React.FC<MainContentProps> = ({  children,target}) => {
  const useChat = useChatContext();
  const [content, setContent] = useState();
  const [userInput, setUserInput] = useState("");
  const { isOpenModal, chatHistory, addChatMessage, generateVTAResponse } = useChatContext();
  const csrfToken = useCsrfToken();
  console.log('csfr',csrfToken)
  
  const chatContainerRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    if (chatContainerRef.current) {
      chatContainerRef.current.scrollTop =
        chatContainerRef.current.scrollHeight;
    }
  }, [chatHistory]);


  // useEffect(() => {
    
  // }, [currentTarget]);

  async function handleChat(ev: any) {
    ev.preventDefault();
    if (userInput.trim()) {
      const VTAResponse = await generateVTAResponse(userInput);
      addChatMessage(userInput, VTAResponse);
      setUserInput(""); // clear user input
    }
  }

  // handle chat submission by pressing ENTER
  async function handleKeyDown(ev: React.KeyboardEvent<HTMLTextAreaElement>) {
    if (ev.key === "Enter") {
      ev.preventDefault(); // Prevent form submission (if the input is inside a form)
      if (userInput.trim()) {
        const VTAResponse = await generateVTAResponse(userInput);
        addChatMessage(userInput, VTAResponse);
        setUserInput(""); // clear user input
      }
    }
  }

  return (
    <>
      <div
        className="min-w-full sm:min-w-[0] w-[100%] px-8 py-6"
        id="page-content-wrapper"
      >
        <HeaderSection />
        {chatHistory.length != 0 && target != 'home' ? (
          <section
            className="flex flex-col gap-3 h-[74vh] border rounded-md mb-2 py-4 px-2 overflow-y-auto overflow-x-hidden"
            ref={chatContainerRef}
          >
            {chatHistory.map((chat, index) => (
              <div className="mb-8 px-2 md:px-4" key={index}>
                <UserChat message={chat.userText} key={index} />
                <BotChat
                  message={chat.VTAText}
                  key={index + 1}
                  chatId={index}
                  like={chat.like}
                  dislike={chat.dislike}
                  currentUserId={useChat.currentUserId}
                />
              </div>
            ))}
          </section>
        ) : (
          <> {children}</>
        )}

        <section>
          <form onSubmit={handleChat} className="flex flex-nowrap  gap-2">
            <div className="mt-2 w-[95%]">
              <textarea
                name="item_description"
                id="item_description"
                className="block w-full main-sec-v2-bg-color px-2 rounded-md border-0 py-1.5 text-white shadow-sm   placeholder:text-gray-400 focus:ring-0  focus:ring-[#adf7de] sm:text-sm sm:leading-6"
                value={userInput}
                onChange={(ev) => setUserInput(ev.target.value)}
                onKeyDown={handleKeyDown}
              ></textarea>
            </div>
            <div className="main-prm-bg-color flex justify-center items-center p-2 rounded  mt-2 h-[3.6rem]">
              <button type="submit" disabled={userInput.length == 0}>
                <Image src="/send.svg" alt="star-icon" width={38} height={38} />
              </button>
            </div>
          </form>
        </section>
      </div>

      <RatingModal isOpen={isOpenModal} />
    </>
  );
};
