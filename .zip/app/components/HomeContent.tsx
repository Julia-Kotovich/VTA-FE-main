import Image from 'next/image';
import React from 'react'

export default function HomeContent() {
  return (
    <section className="flex flex-col gap-3 justify-center items-center h-[74vh] border rounded-md mb-2">
      <div>
        <Image src="/bot.svg" alt="star-icon" width={100} height={100} />
      </div>
      <div className="text-center main-prm-color">
        <h5>
          Hi, I am your 
          <span className="bot-font text-lg"> Virtual Assistant</span> for
          Capstone Project <br />
          <span className="bot-font">How Can I assist you today?</span>
        </h5>
      </div>
    </section>
  );
}
